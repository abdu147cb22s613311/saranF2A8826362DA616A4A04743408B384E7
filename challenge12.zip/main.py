#leap year
def isLeapYear(year):
  if(Year % 4==0 and Year % 100!=0):
     return True 
  else:
     return False
Year=2012
if isLeapYear(Year):
    print("{} is a Leap year".format(Year))
else:
 print("{}is not a leap year".format(Year))